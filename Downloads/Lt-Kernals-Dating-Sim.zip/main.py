import random
import colorama
from colorama import Fore, Style

#Variables
money = 0
age = 0
grade = 0
smart = random.randint(0, 50)
strength = 0
looks = random.randint (0, 100)
relationships = False
school = False
gay = False
straight = False
male = False
female = False
yourGender = ["male", "female"]
mVar = 1

#End of Variables

#Arrays
partner1 = ["Sam" , "Arnold" , "Gregory" , "Pete", "Esteban", "Owen", "Liam", "Trevor", "Gavin", "Geoff", "Jeff", "Justin", "Ethan", "Eric", "Cole", "Brandon", "Dustin", "Austin", "Evan", "Noah", "Matthew", "Dylan", "Aidan", "Christopher", "Josh", "Cordell"]
partner2 = ["Samantha", "Maddie", "Maddy", "Catherine", "Juliet", "Alika", "Simmi", "Kia", "Julie", "Amanda", "Erika", "Saddie", "Ruby", "Fuk Me", "Fuk Yu", "Wynter", "Allyson", "Summer", "Cinnamon", "Dolley", "Honey", "Paige", "Princess", "Victoria", "Vikky", "Kayla", "Jannet", "Zoey", "Zoe", "Chelsea", "Sandy", "Sandra", "Alexandra", "Amalia", "Amelia", "Makayla", "Talia", "Makenna", "Kendall", "Emma", "Cora", "Marley", "Heather", "Savannah", "Janelle"]
dad = ["Carl", "Steve", "Josh", "Cordell", "Ethan", "Arnold", "Barry", "Charles", "Clarence", "Clifford", "David", "Donald", "Errol", "Frank", "Grant", "Gregory", "Henry", "James", "Juan", "Kenneth", "Lionel", "Miguel", "Norman", "Oscar", "Peter", "Quincy", "Randy", "Richard", "Robert", "Roger", "Samuel", "Silas", "Thomas", "Timothy", "Victor", "Bob", "Mike", "Matt", "Terry", "Jamie", "Anthony"]
mom = ["Kim", "Kerren", "Pat", "Kathy", "Susan", "ZueXi", "Amanda", "Kathren", "Maddie", "Maddy", "Hannah", "Barb", "Sharon", "Lisa", "Brittany", "Lyndsay", "Melanie", "Ashley", "Lori", "Judy", "Carol", "Stacy", "Amber", "Penny" ]
month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
day = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]
deaths = ["Old Age", "AIDS", "Heart Attack", "Stroke", "Gayness", "Brain Cancer", "Tumour", "Xi Shot You", "Bronk-Something Shomething", "Erectile Disfunction"]


#End of Arrays

#Random Generators

x = dad[random.randint(0, 39)]
y = mom[random.randint(0, 22)]
z = random.randint(1600, 2020)
w = month[random.randint(0, 11)]
e = day[random.randint(0, 30)]
##o = city[random.randint(0, 16)]
doopers = random.randint(15, 30)
doopers2 = random.randint(15, 30)
girlfriend = partner2[random.randint(0, 44)]
boyfriend = partner1[random.randint(0, 25)]
gender = yourGender[random.randint(0,1)]
relationship = ["You're not dating anyone", str(girlfriend)] 
parentDeath1 = random.randint(40, 60)
parentDeath2 = random.randint(40, 60)
deathss = deaths[random.randint(0,9)]
#End of Generators 



def check(age, strength, z, grade, money, straight, female, relationships):
  actuallyDeathLikeDeath(age, z)
  #rE = randomEvents[random.randint(0,1)]
  answer = input("""What do you want to do?
  Age up = e
  Stats = s 
  Actions = a
   """)
  if gender == 0:
    male = True
    print (male)
  else:
    female = True
    male = False
  if answer.lower() == "e":
    age += 1
    z += 1
    
    dating(gender, straight, age, grade, z, relationship, relationships)
    ranEvents(age)
    gays(age, gay, straight)
    addStrength(age, strength, z, straight)
  
    print("""
    """) #End of If "e"
    
  elif answer.lower() == "s":
    print(Fore.MAGENTA + "You have $" + str(money))
    print(Fore.BLUE + "Your smart are : " + str(smart) + "%")
    print(Fore.YELLOW + "Your strength is : " + str(strength) + "%")
    print(Fore.GREEN + "Your looks are : " + str(looks) + "%")
    if relationships == True:
      print(Fore.RED + "You're dating " + str(relationship[1]))
    else:
      print(Fore.RED +str(relationship[0]))
    print(Fore.CYAN + "Your grade is " + str(grade))
    print(Style.RESET_ALL)
    check(age, strength, z, grade, money, straight, female, relationships)#End of If "s"
  elif answer.lower() == "a":
    action(age, strength, smart, z)
    check(age, strength, z, grade, money, straight, female, relationships)#End of If "a"
  else:
    print ("Sorry, Try another letter")
    check(age, strength, z, grade, money, straight, female, relationships)
##End check()

def actuallyDeathLikeDeath(age, z):
  if age >= 80 and age == doopers2 and age< 100:
    print("You have died of " + str(deathss) + " On " + str(z))
    exit() 

def addStrength(age, strength, z, straight):
  print("You are " + str(age) + " years old.")
  print ("The year is " + str(z))
  school(age, grade, z)
  if age == 5:
      strength += 10
      check(age, strength, z, grade, money, money)
  elif age == 10:
    strength += 10
    check(age, strength, z, grade, money, straight, female, relationships)
  elif age == 15:
    strength += 10
    check(age, strength, z, grade, money, straight, female, relationships)
  elif age == 20:
    strength += 10
    check(age, strength, z, grade, money, straight, female, relationships)        
  else:
    check(age, strength, z, grade, money, straight, female, relationships)
#End addStrength()

def school(age, grade, z):
  if age == 5:
   school == True
   grade += 1
   print("")
   print (Fore.MAGENTA + "You've started school ")
   print(Style.RESET_ALL)
   check(age, strength, z, grade, money, straight, female, relationships)
   if age >= 18:
    school == False
    grade == "completed"
    if age > 5 and age < 18:
      grade += 1
      check(age, strength, z, grade, money, straight, female, relationships)
    if age == 18:
      print(Fore.MAGENTA + "You've finished sch]ool")
      print(Style.RESET_ALL)
  ##End of School

def actionTwo(age, strength, smart, z): #Ages 11-15
    if age >= 11 and age <= 15:
      answer = input("""What do you want to do?
      Play with Lego = L
      Play Outside = O
      Play on Computer = C""")
      if answer.lower() == "l":
       print("You played with Lego")
       smart += 1
       check(age, strength, z, grade, money, straight, female, relationships)
      
      elif answer.lower() == "o":
        print("You played outside")
        smart += 1
        strength += 1
        check(age, strength, z, grade, money, straight, female, relationships)

      elif answer.lower() == "c":
        print("You played computer games")
        smart -= 3
        check(age, strength, z, grade, money, straight, female, relationships)

      else:
        print("That is not an action. Try again")
        check(age, strength, z, grade, money, straight, female, relationships)
#End of ActionTwo (Ages 11-15)        

def actionThree(age, strength, smart, z): #Ages 16-20
    if age >= 16 and age <= 20 :
      answer = input("""Your actions are:
    
      Date = d
      Play Video Games = v
      Work out = w
      Play sports with friends = s """)
      if answer.lower() == "d":
        print()

      elif answer.lower() == "v":
        print()

      elif answer.lower() == "w":
        print()

      elif answer.lower() == "s":
        print()

      else:
        print("That is not an action. Try again")
    else:
      print (Fore.RED + "Sorry, No Actions available")
      print(Style.RESET_ALL)
      print ("")
#End of actionThree (Ages 16-20)

def action(age, strength, smart, z): #Ages 5-10
  if age >= 5 and age <= 10: 
    answer = input("""Your actions are: 
    Coloring books = c
    Learning to ride a bicycle = b
    Jump rope = r
    OR   
    Do a puzzle = p
  
    What do you want to do?
    """)
    if answer.lower() == "c":
      smart += 2
      print(z)
      check(age, strength, z, grade, money, straight, female, relationships)
      
    elif answer.lower() == "b":
      strength += 2
      print("")
      check(age, strength, z, grade, money, straight, female, relationships)
      
    elif answer.lower() == "r":
      strength += 2
      print("")
      check(age, strength, z, grade, money, straight, female, relationships)
      
    elif answer.lower() == "p":
      smart += 1
      print("")
      check(age, strength, z, grade, money, straight, female, relationships)

  else:
    actionTwo(age, strength, smart, z)
    actionThree(age, strength, smart, z)
    check(age, strength, z, grade, money, straight, female, relationships)  
##End of actions (Ages 5-10)


def dad(x, y, z, gender):
  print ("Your dad is named " + str(x))
  print ("And your moms name is " + str(y))
  print ("And you were born on " + str(w) + " " + str(e) + ", " + str(z) + " " + "in" + " As a " + str(gender))

  print ("")
  check(age, strength, z, grade, money, straight, female, relationships)
#End of dad()

def gays(age, gay, straight):
  if age == 13:
    answer = input(Fore.RED + """ALERT
    Are you gay or straight?
    
    gay = g
    straight = s
    
    """)
    print(Style.RESET_ALL)

    if answer.lower() == "g":
      gay = True
      straight = False
      ##check(age, strength, z, grade, money, straight, female, relationships)    

    elif answer.lower() == "s":
      #xes = sex[1]
      straight = True
      ##check(age, strength, z, grade, money, straight, female, relationships)
      
    else:
      print("Not a letter bud")
      gays(age, gay, straight)
#End of gays() ... Sorry Mr. J, PRAISE JESUS

#def randomEvent(randomEvents):
  #print (randomEvents)
  #check(age, strength, z, grade, money, straight, female, relationships)

def dating(gender, straight, age, grade, z, relationship, relationships):
   if age == doopers:## and straight == True: 
     #Doopers is random age 15-30
    answer = input(Fore.BLUE + str(girlfriend) + " just confessed their love for you!" """
    Do you want to date them?
      """)
      
    if answer.lower() == "yes":
      relationships = True
      print(Style.RESET_ALL)
      print(Fore.YELLOW + "You are dating " + str(girlfriend))
      print(Style.RESET_ALL)
      
    elif answer.lower() == "no":
      print(Fore.YELLOW + "Aight. Friendzone it is.")
      print(Style.RESET_ALL)
      
    else:
      print("What do you want to do?")
      dating(gender, straight, age, grade, z, relationship, relationships)
     ##check(age, strength, z, grade, money, straight, female, relationships)
  
def ranEvents(age):
  doopers3 = random.randint(0, 100)
  if age == doopers3:
    disasterThings(mVar)
    print("Boom disaster")
    

parents = ["Mom", "Dad"]
def disasterThings(mVar):
  diseases = ["Ebola", "Ecoli", "a Gunshot Wound", "Polio", "HIV", "AIDS", "Clamidia", "Genital Warts", "Gayness", "Measels", "Tuberculosis", "Crippling Depression", "Heart Attack", "Stroke", "Seizure", "Kidney Failure"]
  disease = diseases[random.randint(0, 14)]
  disasters = ["Tornado", "Earthquake", "Hail Storm", "Tsunami", "Volcano"]
  disaster =  disasters[random.randint(0,4)]
  if age == parentDeath1:
      del parents[0]
      parents.insert(0, "buffer")
      print (Fore.ORANGE + "Your Mother has died of old age. So sad.")
      mVar == 3
  if age == parentDeath2:
      del parents[1]
      parents.insert(1, "buffer")
      print (Fore.ORANGE + "Your Father has died of old age. So sad.")
      mVar == 2
  if parents.count("Dad") == 0 and parents.count("Mom") == 0:
   print("We good")
   ## check(age, strength, z, grade, money, straight, female, relationship)
  else:
    if mVar == 1:
      m = parents[random.randint(0,1)] #For the random parents generation
      if m == "Mom":
        randomEvents = ["Your " + str(m) + " has died of " + str(disease) + ".", "Your home has been ravished by a " + str(disaster) + "."]
        rE = randomEvents[random.randint(0,1)]
        del parents[0]
        parents.insert(0, "buffer")
        print (Fore.GREEN + rE)
        print(Style.RESET_ALL)
        mVar == 2
      else:
        randomEvents = ["Your " + str(m) + " has died of " + str(disease) + ".", "Your home has been ravished by a " + str(disaster) + "."]
        rE = randomEvents[random.randint(0,1)]
        del parents[1]
        parents.insert(1, "buffer")
        print (Fore.GREEN + rE)
        print(Style.RESET_ALL)
        mVar == 3
    elif mVar == 2:
      m = parents[0] #For the random parents generation
      if m == "Mom":
        randomEvents = ["Your " + str(m) + " has died of " + str(disease) + ".", "Your home has been ravished by a " + str(disaster) + "."]
        rE = randomEvents[random.randint(0,1)]
        del parents[0]
        parents.insert(0, "buffer")
        print (Fore.GREEN + rE)
        print(Style.RESET_ALL)
        mVar == 2
      else:
        randomEvents = ["Your " + str(m) + " has died of " + str(disease) + ".", "Your home has been ravished by a " + str(disaster) + "."]
        rE = randomEvents[random.randint(0, 1)]
        del parents[1]
        parents.insert(1, "buffer")
        print (Fore.GREEN + rE)
        print(Style.RESET_ALL)
        mVar == 3
    elif mVar == 3:
      m = parents[1] #For the random parents generation
      if m == "Mom":
        randomEvents = ["Your " + str(m) + " has died of " + str(disease) + ".", "Your home has been ravished by a " + str(disaster) + "."]
        rE = randomEvents[random.randint(0,1)]
        del parents[0]
        parents.insert(0, "buffer")
        print (Fore.GREEN + rE)
        print(Style.RESET_ALL)
        mVar == 2
      else:
        randomEvents = ["Your " + str(m) + " has died of " + str(disease) + ".", "Your home has been ravished by a " + str(disaster) + "."]
        rE = randomEvents[random.randint(0, 1)]
        del parents[1]
        parents.insert(1, "buffer")
        print (Fore.GREEN + rE)
        print(Style.RESET_ALL)
        mVar == 3
    


#Manually coded "Switch" event. After deleting the mom or dad from the array, I inserted a buffer to keep the array the same length so the randint would still work and find the same stuff. It pretty much counts the amount of times it finds mom or dad in the array and if its zero, they're both dead. It can be much simpler and I know how to do it, but i dont want to do the work lol.


dad(x, y, z, gender)

