import random
import time
##import replit
used = []
def function():
  s = random.randint(1, 6)
  print("Your last rolls were " + str(used))
  roll = input("Do you want to roll the dice?[y/n]")
  ##replit.clear()
  if(roll.lower() == "y"):
    print("Rolling... Please wait...")
    time.sleep(5)
    ##replit.clear()
    if(s == 1):
      print(""" 
      
         0  

      """)
      print("The roll was " + str(s))
      used.append(s)
      function()
    elif(s == 2):
      print("""
      0
                  
          0
      """)
      print("The roll was " + str(s))
      used.append(s)
      function()
    elif(s == 3):
      print("""
      0
        0
          0
      """)
      print("The roll was " + str(s))
      used
      function()
    elif(s == 4):
      print("""
      0    0
      
      0    0
      """)
      print("The roll was " + str(s))
      used.append(s)
      function()
    elif(s == 5):
      print("""
      0     0
         0   
      0     0
      """)
      print("The roll was " + str(s))
      used.append(s)
      function()
    elif(s == 6):
      print("""
      0    0
      0    0
      0    0
      """)
      print("The roll was " + str(s))
      used.append(s)
      function()
  elif(roll.lower() == "n"):
    print("Okay, Terminating the program")
  else:
    print("Thats not a valid keypress")
    function()






function()