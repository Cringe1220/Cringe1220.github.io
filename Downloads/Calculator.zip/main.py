import math
import replit
a = 0
b = 0
c = 0.0
def everything():
  global a
  global b
  global c
  do = input("""Which operator do you want to use?
  """)
  if (do == "+"):
    print("a + b = _")
    a = input("What is A?")
    print(a + " + b = _")
    b = input("What is B?")
    c = float(a) + float(b)
    replit.clear()
    print (str(a) + " + " + str(b) + " = " + str(c))
    everything()
  elif(do == "-"):
    print("a - b = c")
    a = input("What is A?")
    print(a + " - b = c")
    b = input("What is B?")
    c = float(a) - float(b)
    replit.clear()
    print(str(a) + " - " + str(b) + " = " + str(c))
    everything()
  elif(do == "*"):
    print("a * b = c")
    a = input("What is A?")
    print(a + " * b = c")
    b = input("What is B?")
    c = float(a) * float(b)
    replit.clear()
    print(str(a) + " * " + str(b) + " = " + str(c))
    everything()
  elif(do == "/"):
    print("a / b = c")
    a = input("What is A?")
    print(a + " / b = c")
    b = input("What is B?")
    replit.clear()
    c = float(a) / float(b)
    print(str(a) + " / " + str(b) + " + " + str(c))
    everything()

  
everything()