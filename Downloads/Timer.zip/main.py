import time
import replit
minu = 0
secu = 00



while minu <= 100000000000000000:
  ##replit.clear()
  print("Welcome to the mythical Timer. Created in Repl")
  print(str(minu) + ":" + str(secu))
  if secu <= 60:
    time.sleep(1)
    secu += 1
  else:
    minu += 1
    secu -= 60
  

