import random
import time
##Imports
cards = 0
wins = 0
loses = 0
busted = 0
def start():
    global cards
    global cards1
    global cards2
    print("Hello, Welcome to my game of Blackjack! To start type Y")
    print("You have won " + str(wins) + " and lost " + str(loses))
    y = input("")
    if y.lower() == "y":
        card1 = random.randint(1,10)
        card2= random.randint(1, 10)
        cards = card1 + card2
        if card1 == 10 and card2 == 1 or card1 == 1 and card2 == 10:
            cards = 21
        print("You were dealt " + str(card1) + " and a " + str(card2))
        print("With a total of " + str(cards))
        game()
    else:
        start()
##End start()
        
def game():
    global cards
    while cards <= 21:
        print("What would you like to do? H = Hit / S = Stand?")
        h = input("")
        if h.lower() == "h":
            p = random.randint(1, 10)
            print(p)
            cards += p
            print(cards)
        elif h.lower() == "s":
            print("AI's turn")
            ai()
    else:
        print("You lose")
        print("AI's turn")
        ai()
##End game()
    

def ai():
    global total
    global cards
    global wins
    card3 = random.randint(1, 10)
    card4 = random.randint(1,10)
    total = card3 + card4
    while total <= 21:
        if total == 17 or total == 18 or total == 19 or total == 20 or total == 21 or total > cards:
            print("I will stand with " + str(total))
            end()
        else:
            time.sleep(2)
            print("I will hit")
            o = random.randint(1, 10)
            total += o
        
    else:
        print("Whoops! You win! I busted with " + str(total))
        wins += 1
        start()
##End ai()


def end():
    global loses
    global wins
    global busted
    if total > cards and total <= 21:
        print("Congratulations, You lost!")
        loses += 1
        start()
    elif cards > total and cards <= 21:
        print("Congratimilations, You Win!!!")
        wins += 1
        start()
    else:
        print("you lost")
        loses += 1
        start()
##End end()

def lose():
    global loses
    print("Haha, you lost, I won with " + str(total))
    loses += 1
    start()
        
    

start()
